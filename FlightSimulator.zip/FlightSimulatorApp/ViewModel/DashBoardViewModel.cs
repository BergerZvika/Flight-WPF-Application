﻿using FlightSimulatorApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlightSimulatorApp.ViewModel
{
    public class DashBoardViewModel : BaseNotify
    {
        private MyModel myModel;
        public DashBoardViewModel(MyModel model)
        {
            myModel = model;
            myModel.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e) { NotifyPropertyChanged("VM_" + e.PropertyName); };
        }

        //proprety
        public double VM_Heading
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Heading);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Heading from server!";
                    return 0;
                }
            }
        }

        public double VM_Altimiter
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Altimiter);

                }
                catch
                {
                    myModel.Message = "Error: Fail while read Altimiter from server!";
                    return 0;
                }
            }
        }
        public double VM_VerticalSpeed
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.VerticalSpeed);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read VerticalSpeed from server!";
                    return 0;
                }
            }
        }

        public double VM_GroundSpeed
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.GroundSpeed);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read GroundSpeed from server!";
                    return 0;
                }
            }
        }

        public double VM_AirSpeed
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.AirSpeed);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read AirSpeed from server!";
                    return 0;
                }
            }
        }

        public double VM_Altitude
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Altitude);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Altitude from server!";
                    return 0;
                }
            }
        }

        public double VM_Roll
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Roll);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Roll from server!";
                    return 0;
                }
            }
        }

        public double VM_Pitch
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Pitch);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Pitch from server!";
                    return 0;
                }
            }
        }
    }
}
