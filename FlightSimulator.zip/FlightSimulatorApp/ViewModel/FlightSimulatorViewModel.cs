﻿using FlightSimulatorApp.Model;
using FlightSimulatorApp.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Text;
using System.Windows;
using System.Windows.Media;

namespace FlightSimulatorApp.ViewModel
{
    public class FlightSimulatorViewModel : BaseNotify
    {
        private MyModel myModel;
        private string ip, port;



        //constractors
        public FlightSimulatorViewModel(MyModel model)
        {
            myModel = model;
            myModel.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e) { NotifyPropertyChanged("VM_" + e.PropertyName);};
            ip = "127.0.0.1";
            port = "5402";
        }

        //connected method
        public void VM_Connect()
        {
            try {
                int portConvert = int.Parse(port);
                myModel.Connect(ip, portConvert);
            }
            catch
            {
                myModel.Message = "Error: Wrong port!";
            }
        }

        public void VM_Disconnect()
        {
            myModel.Stop();
        }

        public bool VM_IsConnect
        {
            get
            {
                return myModel.IsConnect;
            }
            set
            {
                myModel.IsConnect = value;
                NotifyPropertyChanged("VM_IsConnect");
            }
        }

        //connected proptrety
        public string VM_Ip
        {
            get
            {
                return this.ip;
            }
            set
            {
                this.ip = value;
                NotifyPropertyChanged("VM_Ip");
            }
        }
        public string VM_Port
        {
            get
            {
                return this.port;
            }
            set
            {
                this.port = value.ToString();
                NotifyPropertyChanged("VM_Port");
            }
        }

        //Message Text
        public string VM_Message
        {
            get
            {
                return myModel.Message;
            }
            set
            {
                myModel.Message = value;
            }
        }
    }
}
