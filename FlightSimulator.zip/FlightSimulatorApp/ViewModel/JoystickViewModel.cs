﻿using FlightSimulatorApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlightSimulatorApp.ViewModel
{
    public class JoystickViewModel : BaseNotify
    {
        private MyModel myModel;
        public JoystickViewModel(MyModel model)
        {
            myModel = model;
            myModel.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e) { NotifyPropertyChanged("VM_" + e.PropertyName); };
        }
        //joystick proprety
        public double VM_Throttle
        {
            set
            {
                if (value != myModel.Throttle)
                {
                    if (value > 1)
                    {
                        value = 1;
                    }
                    else if (value < 0)
                    {
                        value = 0;
                    }
                    myModel.Throttle = value;
                    string str = "set /controls/engines/current-engine/throttle " + value.ToString();
                    myModel.Send(str);
                }
            }
        }

        public double VM_Aileron
        {
            set
            {
                if (value != myModel.Aileron)
                {
                    if (value > 1)
                    {
                        value = 1;
                    }
                    else if (value < -1)
                    {
                        value = -1;
                    }
                    myModel.Aileron = value;
                    string str = "set /controls/flight/aileron " + value.ToString();
                    myModel.Send(str);
                }

            }
        }

        public double VM_Rudder
        {
            set
            {
                if (value != myModel.Rudder)
                {
                    if (value > 1)
                    {
                        value = 1;
                    }
                    else if (value < -1)
                    {
                        value = -1;
                    }
                    myModel.Rudder = value;
                    string str = "set /controls/flight/rudder " + value.ToString();
                    myModel.Send(str);
                }
            }
        }

        public double VM_Elevator
        {
            set
            {
                if (value != myModel.Elevator)
                {
                    if (value > 1)
                    {
                        value = 1;
                    }
                    else if (value < -1)
                    {
                        value = -1;
                    }
                    myModel.Elevator = value;
                    string str = "set /controls/flight/elevator " + value.ToString();
                    myModel.Send(str);
                }
            }
        }
    }
}
