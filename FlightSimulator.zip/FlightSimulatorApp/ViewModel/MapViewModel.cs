﻿using FlightSimulatorApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlightSimulatorApp.ViewModel
{
    public class MapViewModel : BaseNotify
    {
        private MyModel myModel;
        private string icon;
        private string[] icons;
        private int i = 0;
        public MapViewModel(MyModel model)
        {
            myModel = model;
            myModel.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e) { NotifyPropertyChanged("VM_" + e.PropertyName); };
            icons = new string[11];
            icons[0] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\paper-plane.png";
            icons[1] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\airplane2.png";
            icons[2] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\airplane3.png";
            icons[3] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\airport4.png";
            icons[4] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\airplane5.png";
            icons[5] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\airplane6.png";
            icons[6] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\spaceship.png";
            icons[7] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\spaceship2.png";
            icons[8] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\spaceship3.png";
            icons[9] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\helicopter.png";
            icons[10] = System.AppDomain.CurrentDomain.BaseDirectory + "\\resources\\hot-air-balloon.png";
            icon = icons[i];
        }

        //map proprety
        public string VM_Location
        {
            get
            {
                return myModel.Location;
            }
        }


        public double VM_Latitude
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Latitude);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Latitude from server!";
                    return 0;
                }
            }
        }

        public double VM_Longitude
        {
            get
            {
                try
                {
                    return Double.Parse(myModel.Longitude);
                }
                catch
                {
                    myModel.Message = "Error: Fail while read Latitude from server!";
                    return 0;
                }
            }
        }

        public string VM_Icon
        {
            get
            {
                return this.icon;
            }
            set
            {
                this.icon = value;
                NotifyPropertyChanged("VM_Icon");
            }
        }

        public void ChangeIcon()
        {
            i += 1;
            i %= 11;
            VM_Icon = icons[i];
        }
    }
}
