﻿using FlightSimulatorApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace FlightSimulatorApp.Model
{
    public class MyModel : BaseNotify, IClient
    {
        //private client data
        private TcpClient myClient;
        public Mutex mutex;
        private bool isConnect;
        private bool end;
        private bool stop;
        private string heading, airSpeed, altitude, altimeter, verticalSpeed, groundSpeed, roll, pitch, latitude, longitude, location, message;
        private double maxLatitude = 85, minLatitude = -86, maxLongitude = 199, minLongitude = -179, rudder, elevator, throttle, aileron;

        //constractor
        public MyModel()
        {
            mutex = new Mutex();
            IsConnect = false;
            end = false;
            //DashBoard intialize
            AirSpeed = Altitude = Roll = Pitch = Altimiter = Heading = GroundSpeed = VerticalSpeed = "0";
            //map values initialize
            Latitude = "32.002644";
            Longitude = "34.888781";
            Location = Latitude + "," + Longitude;
            //Message
            message = "Hello World!";
        }


        //proprety
        public string Altimiter
        {
            get
            {
                return altimeter;
            }
            set
            {
                altimeter = value;
                NotifyPropertyChanged("Altimiter");
            }
        }
        public string AirSpeed
        {
            get
            {
                return airSpeed;
            }
            set
            {
                airSpeed = value;
                NotifyPropertyChanged("AirSpeed");
            }
        }
        public string Altitude
        {
            get
            {
                return altitude;
            }
            set
            {
                altitude = value;
                NotifyPropertyChanged("Altitude");
            }
        }
        public string Heading
        {
            get 
            { 
                return heading; 
            }
            set
            {
                 heading = value;
                 NotifyPropertyChanged("Heading");
            }
        }


        public string VerticalSpeed
        {
            get 
            { 
                return verticalSpeed; 
            }
            set
            {
                 verticalSpeed = value;
                 NotifyPropertyChanged("VerticalSpeed");
            }
        }
        public string GroundSpeed
        {
            get 
            { 
                return groundSpeed; 
            }
            set
            {
                 groundSpeed = value;
                 NotifyPropertyChanged("GroundSpeed");
            }
        }
        public string Roll
        {
            get 
            { 
                return roll; 
            }
            set
            {
                 roll = value;
                 NotifyPropertyChanged("Roll");
            }
        }

        public string Pitch
        {
            get 
            { 
                return pitch;
            }
            set
            {
                 pitch = value;
                 NotifyPropertyChanged("Pitch");
            }
        }

        //map proprety
        public string Latitude
        {
            get 
            { 
                return latitude; 
            }
            set
            {
                try
                {
                    latitude = value;
                    if (Double.Parse(value) > maxLatitude)
                    {
                        latitude = (minLatitude).ToString();
                    }
                    else if (Double.Parse(value) < minLatitude)
                    {
                        latitude = (maxLatitude).ToString();
                    }
                    NotifyPropertyChanged("Latitude");
                }
                catch
                {
                    Message = "Error: Fail while read Latitude from server!";
                }
            }
        }

        public string Longitude
        {
            get 
            { 
            return longitude; 
            }
            set
            {
                try
                {
                    longitude = value;
                    if (Double.Parse(value) > maxLongitude)
                    {
                        longitude = (minLongitude + 1).ToString();
                    }
                    else if (Double.Parse(value) < minLongitude)
                    {
                        longitude = (maxLongitude - 1).ToString();
                    }
                    NotifyPropertyChanged("Longitude");
                }
                catch
                {
                    Message = "Error: Fail while read Longitude from server!";

                }
            }
        }
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
                NotifyPropertyChanged("Location");

            }
        }


        //JoyStick proprety
        public double Rudder
        {
            get 
            { 
                return rudder; 
            }
            set
            {
                    rudder = value;
                    NotifyPropertyChanged("Rudder");
            }
        }
        public double Elevator
        {
            get 
            { 
                return elevator; 
            }
            set
            {
                    elevator = value;
                    NotifyPropertyChanged("Elevator");
            }
        }
        public double Throttle
        {
            get 
            { 
                return throttle; 
            }
            set
            {
                    throttle = value;
                    NotifyPropertyChanged("Throttle");
            }
        }
        public double Aileron
        {
            get 
            { 
                return aileron; 
            }
            set
            {
                    aileron = value;
                    NotifyPropertyChanged("Aileron");
            }
        }

        public bool IsConnect
        {
            get
            {
                return this.isConnect;
            }
            set
            {
                this.isConnect = value;
                NotifyPropertyChanged("IsConnect");
            }
        }

        //Message proprety
        public string Message
        {
            get
            {
                return this.message;
            }
            set
            {
                this.message = value;
                NotifyPropertyChanged("Message");
            }
        }

        //public client method
        public void Connect(string ip, int port)
        {
            try
            {
                myClient = new TcpClient();
                myClient.Connect(ip, port);
                IsConnect = true;
                stop = false;
                myClient.GetStream().ReadTimeout = 10000;
                myClient.GetStream().WriteTimeout = 10000;
                Read();
                Message = "Connect";
            }
            catch
            {
                myClient.Close();
                Message = "Error: Fail while connect to server!";
            }
        }

        public void Stop()
        {
            if (isConnect)
            {
                IsConnect = false;
                stop = true;
                myClient.Close();
                Message = "Disconnect";
            }
        }

        public void Send(string data)
        {
            data += "\n";
            if (isConnect)
            {
                try
                {
                    mutex.WaitOne();
                    byte[] read = Encoding.ASCII.GetBytes(data);
                    myClient.GetStream().Write(read, 0, read.Length);
                    byte[] buffer = new byte[1024];
                    myClient.GetStream().Read(buffer, 0, 1024);
                    string newData = Encoding.ASCII.GetString(buffer, 0, buffer.Length);
                    mutex.ReleaseMutex();
                } catch 
                {
                    mutex.ReleaseMutex();
                    Stop();
                    Message = "Error: Fail while send command to server!";
                }
            }
        }

        public string Recieve(string data)
        {
            if (isConnect)
            {
                try
                {
                    mutex.WaitOne();
                    byte[] read = Encoding.ASCII.GetBytes(data);
                    myClient.GetStream().Write(read, 0, read.Length);
                    byte[] buffer = new byte[1024];
                    StringBuilder newData = new StringBuilder();
                    do
                    {
                        myClient.GetStream().Read(buffer, 0, buffer.Length);
                        newData.Append(Encoding.ASCII.GetString(buffer, 0, buffer.Length));
                        for (int i = 0; i < 1024; i++)
                        {
                            if (buffer[i] == 10)
                            {
                                end = true;
                                break;
                            }

                        }
                    } while (!end);
                    end = false;
                    mutex.ReleaseMutex();
                    string ret = newData.ToString();
                    return ret;
                }
                catch
                {
                    mutex.ReleaseMutex();
                    Stop();
                    
                    Message = "Error: Fail while read command from server!";
                    return null;
                }
            }
            return null;
        }

        //public model method
        public void Read()
        {
            //listen Thread to server. 
            new Thread(delegate ()
            {
                while (!stop)
                {
                    try
                    {
                        //reading dash board values
                        AirSpeed = Recieve("get /instrumentation/airspeed-indicator/indicated-speed-kt\n");
                        Altitude = Recieve("get /instrumentation/gps/indicated-altitude-ft\n");
                        Roll = Recieve("get /instrumentation/attitude-indicator/internal-roll-deg\n");
                        Pitch = Recieve("get /instrumentation/attitude-indicator/internal-pitch-deg\n");
                        Altimiter = Recieve("get /instrumentation/altimeter/indicated-altitude-ft\n");
                        Heading = Recieve("get /instrumentation/heading-indicator/indicated-heading-deg\n");
                        GroundSpeed = Recieve("get /instrumentation/gps/indicated-ground-speed-kt\n");
                        VerticalSpeed = Recieve("get /instrumentation/gps/indicated-vertical-speed\n");
                        //reading map values
                        Latitude = Recieve("get /position/latitude-deg\n");
                        Longitude = Recieve("get /position/longitude-deg\n");
                        Location = latitude + "," + longitude;
                        Thread.Sleep(250);
                    }
                    catch (ArgumentNullException)
                    {
                        Stop();
                                            ////////////////////////////////////////////////////////////////////////////
                    Message = "Error: Fail while read commands from server!";
                    }
                }
            }).Start();
        }
    }
}
