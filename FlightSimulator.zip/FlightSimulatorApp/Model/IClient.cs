﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorApp.Model
{
    public interface IClient
    {
        public void Connect(string ip, int port);
        public void Stop();
        public void Send(string data);
       public string Recieve(string data);
    }
}