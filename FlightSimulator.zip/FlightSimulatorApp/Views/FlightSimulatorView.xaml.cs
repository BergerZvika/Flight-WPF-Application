﻿using FlightSimulatorApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FlightSimulatorApp.Views
{
    /// <summary>
    /// Interaction logic for FlightSimulatorView.xaml
    /// </summary>
    public partial class FlightSimulatorView : Window
    {
        private FlightSimulatorViewModel viewmodel;
        public FlightSimulatorView(string ip, string port)
        {
            InitializeComponent();
            viewmodel = (Application.Current as App).viewmodel;
            mapView.DataContext = (Application.Current as App).mvm;
            db.DataContext = (Application.Current as App).dbvm;
            newJs.DataContext = (Application.Current as App).jvm;
            MessageText.DataContext = viewmodel;
            DataContext = viewmodel;
            viewmodel.VM_Ip = ip;
            viewmodel.VM_Port = port;
        }

        private void NewJS_Loaded(object sender, RoutedEventArgs e) { }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            viewmodel.VM_Connect();
        }
        private void b2_Click(object sender, RoutedEventArgs e)
        {
            viewmodel.VM_Disconnect();
        }

        private void b3_Click_1(object sender, RoutedEventArgs e)
        {
            Info inf = new Info();
            inf.DataContext = (Application.Current as App).viewmodel;
            inf.Show();
        }

        private void b4_Click(object sender, RoutedEventArgs e)
        {
            if (viewmodel.VM_IsConnect)
            {
                viewmodel.VM_Disconnect();
            }
            Window mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void b5_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current as App).mvm.ChangeIcon();

        }

        private void b6_Click(object sender, RoutedEventArgs e)
        {
            if (viewmodel.VM_IsConnect)
            {
                viewmodel.VM_Disconnect();
            }
            this.Close();
        }
    }
}

 