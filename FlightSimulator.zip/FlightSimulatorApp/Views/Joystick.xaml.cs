﻿using FlightSimulatorApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;


namespace FlightSimulatorApp.Views
{
    /// <summary>
    /// Interaction logic for Joystick.xaml
    /// </summary>
    public partial class Joystick : UserControl
    {
        //aileron proprety
        public double Rudder
        {
            get 
            { 
                return Convert.ToDouble(GetValue(RudderProperty)); 
            }
            set 
            { 
                SetValue(RudderProperty, value); 
            }
        }

        public static readonly DependencyProperty RudderProperty = DependencyProperty.Register("Rudder", typeof(double), typeof(Joystick), null);
    
        //elevator proprety
        public double Elevator
        {
            get 
            { 
                return Convert.ToDouble(GetValue(ElevatorProperty)); 
            }
            set 
            { 
                SetValue(ElevatorProperty, value); 
            }
        }

        public static readonly DependencyProperty ElevatorProperty = DependencyProperty.Register("Elevator", typeof(double), typeof(Joystick), null);
        
        //private field
        private Point start_Position;
        private double totalWidth, totalHeight;
        private readonly Storyboard centerKnob;
        private bool isPressed;

        public Joystick()
        {
            InitializeComponent();
            Knob.MouseLeftButtonDown += Knob_MouseLeftButtonDown;
            Knob.MouseMove += Knob_MouseMove;
            Knob.MouseLeftButtonUp += Knob_MouseLeftButtonUp;
            centerKnob = Knob.Resources["CenterKnob"] as Storyboard;
            isPressed = true;
        }

        private void Knob_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            start_Position = e.GetPosition(Base);
            totalWidth = Base.ActualWidth - KnobBase.ActualWidth;
            totalHeight = Base.ActualHeight - KnobBase.ActualHeight;
            isPressed = true;
            Knob.CaptureMouse();
            centerKnob.Stop();
        }

        private void Knob_MouseMove(object sender, MouseEventArgs e)
        {
            if (isPressed)
            {
                Point newPos = e.GetPosition(Base);

                Point deltaPos = new Point(newPos.X - start_Position.X, newPos.Y - start_Position.Y);

                double distance = Math.Round(Math.Sqrt(deltaPos.X * deltaPos.X + deltaPos.Y * deltaPos.Y));
                if (distance >= totalWidth / 2 || distance >= totalHeight / 2)
                    return;
                Elevator = -deltaPos.Y / 124.0;
                Rudder = deltaPos.X / 124.0;

                knobPosition.X = deltaPos.X;
                knobPosition.Y = deltaPos.Y;
            }
        }

        private void Knob_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Knob.ReleaseMouseCapture();
            centerKnob.Begin();
            isPressed = false;
            Elevator = Rudder = 0;
        }

        private void centerKnob_Completed(object sender, EventArgs e) {}
    }
}
