﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using FlightSimulatorApp.Model;
using FlightSimulatorApp.ViewModel;

namespace FlightSimulatorApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public MyModel model;
        public DashBoardViewModel dbvm;
        public MapViewModel mvm;
        public JoystickViewModel jvm;
        public FlightSimulatorViewModel viewmodel;
        public MainWindow mainWindow;
        private void Application_Startup(Object sender, StartupEventArgs e)
        {
            model = new MyModel();
            viewmodel = new FlightSimulatorViewModel(model);
            dbvm = new DashBoardViewModel(model);
            mvm = new MapViewModel(model);
            jvm = new JoystickViewModel(model);

            mainWindow = new MainWindow();
            mainWindow.Show();
        }

    }
}